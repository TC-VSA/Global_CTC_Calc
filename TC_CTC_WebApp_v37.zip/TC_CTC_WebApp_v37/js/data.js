/* ============================================================
   DATA.JS — Minimum Wage Master + Client Config + Defaults (v37)
   ============================================================ */
var TC_DATA = (function(){
  'use strict';

  /* ── Minimum Wage Seed Data (state-wise, skill-wise) ── */
  var MW_SEED = [
    {s:'Andhra Pradesh',r:'01-Apr-2024',u:13000,ss:14200,sk:15300,hs:17000},
    {s:'Arunachal Pradesh',r:'01-Apr-2024',u:12500,ss:13500,sk:14800,hs:16200},
    {s:'Assam',r:'01-Apr-2024',u:11805,ss:12700,sk:13900,hs:15100},
    {s:'Bihar',r:'01-Oct-2023',u:12000,ss:13100,sk:14400,hs:15700},
    {s:'Chhattisgarh',r:'01-Apr-2024',u:12800,ss:14000,sk:15200,hs:16500},
    {s:'Delhi',r:'01-Oct-2024',u:18066,ss:19929,sk:21917,hs:24116},
    {s:'Goa',r:'01-Apr-2024',u:14000,ss:15300,sk:16800,hs:18200},
    {s:'Gujarat',r:'01-Apr-2024',u:13060,ss:14200,sk:15500,hs:17000},
    {s:'Haryana',r:'01-Jul-2024',u:13800,ss:15200,sk:16700,hs:18200},
    {s:'Himachal Pradesh',r:'01-Apr-2024',u:12800,ss:14000,sk:15300,hs:16700},
    {s:'Jharkhand',r:'01-Apr-2024',u:12000,ss:13200,sk:14500,hs:15800},
    {s:'Karnataka',r:'01-Apr-2024',u:14500,ss:15800,sk:17200,hs:18700},
    {s:'Kerala',r:'01-Apr-2024',u:14500,ss:15800,sk:17300,hs:18800},
    {s:'Madhya Pradesh',r:'01-Apr-2024',u:12500,ss:13700,sk:15000,hs:16300},
    {s:'Maharashtra',r:'01-Jan-2024',u:14170,ss:15490,sk:16960,hs:18500},
    {s:'Manipur',r:'01-Apr-2024',u:12000,ss:13000,sk:14200,hs:15500},
    {s:'Meghalaya',r:'01-Apr-2024',u:12000,ss:13000,sk:14200,hs:15500},
    {s:'Mizoram',r:'01-Apr-2024',u:12200,ss:13300,sk:14500,hs:15800},
    {s:'Nagaland',r:'01-Apr-2024',u:12000,ss:13000,sk:14200,hs:15500},
    {s:'Odisha',r:'01-Apr-2024',u:12400,ss:13500,sk:14800,hs:16100},
    {s:'Punjab',r:'01-Apr-2024',u:13500,ss:14800,sk:16200,hs:17600},
    {s:'Rajasthan',r:'01-Apr-2024',u:13350,ss:14600,sk:16000,hs:17400},
    {s:'Sikkim',r:'01-Apr-2024',u:13500,ss:14800,sk:16200,hs:17600},
    {s:'Tamil Nadu',r:'01-Apr-2024',u:14100,ss:15400,sk:16800,hs:18300},
    {s:'Telangana',r:'01-Apr-2024',u:13600,ss:14900,sk:16300,hs:17700},
    {s:'Tripura',r:'01-Apr-2024',u:12200,ss:13300,sk:14500,hs:15800},
    {s:'Uttar Pradesh',r:'01-Apr-2024',u:12500,ss:13700,sk:15000,hs:16300},
    {s:'Uttarakhand',r:'01-Apr-2024',u:12800,ss:14000,sk:15300,hs:16700},
    {s:'West Bengal',r:'01-Apr-2024',u:12800,ss:14000,sk:15300,hs:16700},
    {s:'Andaman & Nicobar',r:'01-Apr-2024',u:13500,ss:14800,sk:16200,hs:17600},
    {s:'Chandigarh',r:'01-Apr-2024',u:15000,ss:16400,sk:17900,hs:19500},
    {s:'Dadra & Nagar Haveli',r:'01-Apr-2024',u:13060,ss:14200,sk:15500,hs:17000},
    {s:'Daman & Diu',r:'01-Apr-2024',u:13060,ss:14200,sk:15500,hs:17000},
    {s:'Jammu & Kashmir',r:'01-Apr-2024',u:13300,ss:14500,sk:15900,hs:17300},
    {s:'Ladakh',r:'01-Apr-2024',u:13300,ss:14500,sk:15900,hs:17300},
    {s:'Lakshadweep',r:'01-Apr-2024',u:13500,ss:14800,sk:16200,hs:17600},
    {s:'Puducherry',r:'01-Apr-2024',u:14100,ss:15400,sk:16800,hs:18300}
  ];

  /* ── Skill Category Keys ── */
  var CATS = ['UNSKILLED','SEMI-SKILLED','SKILLED','HIGHLY SKILLED'];
  var CAT_KEY = {UNSKILLED:'u','SEMI-SKILLED':'ss',SKILLED:'sk','HIGHLY SKILLED':'hs'};

  /* ── Default Statutory Configuration ── */
  var CFG_DEFAULT = {
    PF_RATE_EE:     0.12,
    PF_RATE_ER:     0.12,  // includes 3.67% EPS
    PF_CEIL:        15000,
    ESI_RATE_EE:    0.0075,
    ESI_RATE_ER:    0.0325,
    ESI_CEIL:       21000,
    BONUS_RATE:     0.0833,
    BONUS_CEIL:     21000,
    GRAT_RATE:      0.0481,
    HRA_METRO:      0.50,
    HRA_NON:        0.40,
    BASIC_PCT:      0.50,
    EDLI_CEIL:      15000,
    EDLI_RATE:      0.005,
    ADM_CHARGE:     0.005,
    PROF_TAX:       200,
    LWF_EE:         0,
    LWF_ER:         0,
    MEDICAL:        0,
    CONV:           1600,
    WASH:           0,
    FOOD:           0,
    MISC_BENEFIT:   0
  };

  /* ── Client Registry ──
     Each client: { code, pw, state, cat, name, formulas, grid, fxCols }
     Formulas: dynamic formula rules (v36+)
  */
  var CLIENTS = {};

  /* ── Admin Default Password ── */
  var ADMIN_PW_DEFAULT = 'admin@tc2024';

  /* ── Public API ── */
  return {
    MW_SEED: MW_SEED,
    CATS: CATS,
    CAT_KEY: CAT_KEY,
    CFG_DEFAULT: CFG_DEFAULT,
    CLIENTS: CLIENTS,
    ADMIN_PW_DEFAULT: ADMIN_PW_DEFAULT
  };
})();