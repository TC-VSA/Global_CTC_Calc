/* ============================================================
   ASSETS.JS — Embedded logo data + image loader (v37)
   All logos are base64 embedded so app is fully standalone
   ============================================================ */
var TC_ASSETS = (function(){
  'use strict';

  /* ── Normal Logo (TC flat logo) ──
     IMPORTANT: Copy the full base64 string from v36 HTML file.
     Search for "data:image/png;base64," in the original file.
     The string starts with "iVBOR" and is ~15KB long.
  */
  var LOGO_NORMAL = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABkCAYAAAA8AQ3AAAA_PLACEHOLDER_COPY_FROM_V36';

  /* ── 3D Hover Logo (TC Logo 4d.png) ──
     IMPORTANT: Convert TC Logo 4d.png to base64 and paste here.
     Use: https://www.base64-image.de/ or browser console:
       const reader = new FileReader();
       reader.onload = () => console.log(reader.result);
       reader.readAsDataURL(file);
  */
  var LOGO_3D = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABkCAYAAAA8AQ3AAAA_PLACEHOLDER_COPY_3D_LOGO';

  /* ── Favicon (small TC icon) ── */
  var FAVICON = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect fill="%2343d6d3" width="32" height="32" rx="6"/><text x="50%25" y="54%25" dominant-baseline="middle" text-anchor="middle" fill="white" font-family="system-ui" font-size="16" font-weight="bold">TC</text></svg>';

  /* ── Apply logos to all logo elements ── */
  function applyLogos(){
    // Gate logos
    var gl = document.getElementById('gateLogo');
    var gl3 = document.getElementById('gateLogo3d');
    if(gl) gl.src = LOGO_NORMAL;
    if(gl3) gl3.src = LOGO_3D;

    // Main header logos
    var ml = document.getElementById('mainLogo');
    var ml3 = document.getElementById('mainLogo3d');
    if(ml) ml.src = LOGO_NORMAL;
    if(ml3) ml3.src = LOGO_3D;

    // Favicon
    var link = document.querySelector('link[rel="icon"]');
    if(!link){
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    link.href = FAVICON;
  }

  /* ── Public API ── */
  return {
    LOGO_NORMAL: LOGO_NORMAL,
    LOGO_3D: LOGO_3D,
    FAVICON: FAVICON,
    applyLogos: applyLogos
  };
})();