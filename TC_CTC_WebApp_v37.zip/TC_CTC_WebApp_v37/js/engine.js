/* ============================================================
   ENGINE.JS — CTC Calculation Core (v37)
   calc(), solveWagesForCTC(), solveWagesForNTH()
   ============================================================ */
var TC_ENGINE = (function(){
  'use strict';

  var CFG; // runtime config (merged from defaults)

  function setCfg(c){ CFG = c; }
  function getCfg(){ return CFG; }

  /* ── Get Minimum Wage for state + category ── */
  function getMW(state, cat){
    var key = TC_DATA.CAT_KEY[cat] || 'ss';
    for(var i=0; i<TC_DATA.MW_SEED.length; i++){
      if(TC_DATA.MW_SEED[i].s === state) return TC_DATA.MW_SEED[i][key] || 0;
    }
    return 0;
  }

  /* ── FORWARD CALCULATION: Wages → Full Structure ── */
  function calc(p){
    var C = CFG;
    var wages = +p.wages || 0;
    var state = p.state || '';
    var cat   = p.cat || 'SEMI-SKILLED';
    var pf    = p.pf === 'Y';
    var metro = p.metro === 'Y';
    var bonus = p.bonus === 'Y';
    var pfBasis = p.pfBasis || 'On 15K';
    var da    = +p.da || 0;
    var fix   = +p.fix || 0;
    var incent = +p.incentPct || 0;
    var etype  = p.etype || 'REGULAR EMP';

    var mw = getMW(state, cat);

    // Basic = MAX(MW, wages * BASIC_PCT)
    var basic = Math.max(mw, Math.round(wages * C.BASIC_PCT));

    // HRA
    var hraRate = metro ? C.HRA_METRO : C.HRA_NON;
    var hra = Math.round(basic * hraRate);

    // Conveyance, Wash, Food (from config)
    var conv = C.CONV || 0;
    var wash = C.WASH || 0;
    var food = C.FOOD || 0;
    var misc = C.MISC_BENEFIT || 0;
    var medical = C.MEDICAL || 0;

    // Gross = Basic + DA + HRA + Conv + Wash + Food + Medical + Misc + Fix
    var gross = basic + da + hra + conv + wash + food + medical + misc + fix;

    // Special Allowance = Wages - Gross (if positive)
    var specAllow = Math.max(0, wages - gross);
    gross += specAllow;

    // ── ESI auto-detection
    var esiApplicable = gross <= C.ESI_CEIL;
    var esiEE = 0, esiER = 0;
    if(esiApplicable){
      esiEE = Math.round(gross * C.ESI_RATE_EE);
      esiER = Math.round(gross * C.ESI_RATE_ER);
    }

    // ── PF
    var pfWage = pf ? (pfBasis === 'On 15K' ? Math.min(basic, C.PF_CEIL) : basic) : 0;
    var pfEE = pf ? Math.round(pfWage * C.PF_RATE_EE) : 0;
    var pfER = pf ? Math.round(pfWage * C.PF_RATE_ER) : 0;

    // ── EDLI + Admin charge
    var edli = pf ? Math.round(Math.min(basic, C.EDLI_CEIL) * C.EDLI_RATE) : 0;
    var admChg = pf ? Math.round(Math.min(basic, C.PF_CEIL) * C.ADM_CHARGE) : 0;

    // ── Bonus
    var bonusAmt = 0;
    if(bonus && basic <= C.BONUS_CEIL){
      bonusAmt = Math.round(basic * C.BONUS_RATE);
    }

    // ── Gratuity
    var gratuity = Math.round(basic * C.GRAT_RATE);

    // ── Prof Tax
    var profTax = C.PROF_TAX || 0;

    // ── LWF
    var lwfEE = C.LWF_EE || 0;
    var lwfER = C.LWF_ER || 0;

    // ── CTC
    var ctc = gross + pfER + esiER + edli + admChg + bonusAmt + gratuity + lwfER;

    // ── Deductions (employee side)
    var totalDeductions = pfEE + esiEE + profTax + lwfEE;

    // ── Net Take Home
    var nth = gross - totalDeductions;

    // ── Incentive + TTC
    var incentiveAmt = Math.round(ctc * incent / 100);
    var ttc = ctc + incentiveAmt;

    // ── Result object
    var result = {
      name: p.name || '', state: state, cat: cat,
      etype: etype, pfApplicable: pf, esiApplicable: esiApplicable,
      metro: metro, bonusApplicable: bonus, pfBasis: pfBasis,
      mw: mw, basic: basic, da: da, hra: hra,
      conv: conv, wash: wash, food: food, medical: medical,
      misc: misc, fix: fix, specAllow: specAllow,
      gross: gross,
      pfEE: pfEE, pfER: pfER, pfWage: pfWage,
      esiEE: esiEE, esiER: esiER,
      edli: edli, admChg: admChg,
      bonus: bonusAmt, gratuity: gratuity,
      profTax: profTax, lwfEE: lwfEE, lwfER: lwfER,
      totalDeductions: totalDeductions,
      nth: nth, ctc: ctc,
      incentPct: incent, incentive: incentiveAmt, ttc: ttc,
      wages: wages
    };
    return result;
  }

  /* ── REVERSE: Target CTC → solve Wages ── */
  function solveWagesForCTC(targetCTC, params){
    var lo = 0, hi = targetCTC * 2, mid, r;
    for(var i = 0; i < 80; i++){
      mid = Math.round((lo + hi) / 2);
      params.wages = mid;
      r = calc(params);
      if(Math.abs(r.ctc - targetCTC) < 2) break;
      if(r.ctc < targetCTC) lo = mid + 1;
      else hi = mid - 1;
    }
    return r;
  }

  /* ── REVERSE: Net Take Home → solve Wages ── */
  function solveWagesForNTH(targetNTH, params){
    var lo = 0, hi = targetNTH * 3, mid, r;
    for(var i = 0; i < 80; i++){
      mid = Math.round((lo + hi) / 2);
      params.wages = mid;
      r = calc(params);
      if(Math.abs(r.nth - targetNTH) < 2) break;
      if(r.nth < targetNTH) lo = mid + 1;
      else hi = mid - 1;
    }
    return r;
  }

  /* ── Public API ── */
  return {
    setCfg: setCfg,
    getCfg: getCfg,
    getMW: getMW,
    calc: calc,
    solveWagesForCTC: solveWagesForCTC,
    solveWagesForNTH: solveWagesForNTH
  };
})();