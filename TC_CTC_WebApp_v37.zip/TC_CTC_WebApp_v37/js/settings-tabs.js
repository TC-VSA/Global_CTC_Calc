/* ============================================================
   SETTINGS TABS — Tab switching logic (v37)
   ============================================================ */
(function(){
  'use strict';
  function initSettingsTabs(){
    const tabs = document.querySelectorAll('.stab');
    const panels = document.querySelectorAll('.spanel');
    if(!tabs.length) return;
    tabs.forEach(function(btn){
      btn.addEventListener('click', function(){
        // Deactivate all tabs
        tabs.forEach(function(b){
          b.classList.remove('active');
        });
        // Hide all panels
        panels.forEach(function(p){
          p.classList.remove('active');
        });
        // Activate clicked tab
        btn.classList.add('active');
        // Show target panel
        var target = btn.getAttribute('data-target');
        var panel = document.getElementById(target);
        if(panel) panel.classList.add('active');
      });
    });
    // Keyboard navigation (arrow keys)
    var tabList = Array.from(tabs);
    tabList.forEach(function(tab, idx){
      tab.addEventListener('keydown', function(e){
        var next;
        if(e.key === 'ArrowRight' || e.key === 'ArrowDown'){
          e.preventDefault();
          next = tabList[(idx + 1) % tabList.length];
        } else if(e.key === 'ArrowLeft' || e.key === 'ArrowUp'){
          e.preventDefault();
          next = tabList[(idx - 1 + tabList.length) % tabList.length];
        } else if(e.key === 'Home'){
          e.preventDefault();
          next = tabList[0];
        } else if(e.key === 'End'){
          e.preventDefault();
          next = tabList[tabList.length - 1];
        }
        if(next){
          next.click();
          next.focus();
        }
      });
    });
  }
  // Init on DOM ready
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', initSettingsTabs);
  } else {
    initSettingsTabs();
  }
})();