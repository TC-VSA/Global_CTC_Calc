/* ============================================================
   FORMULA.JS — Dynamic Formula Builder Engine (v37)
   Tokenizer → RPN → Evaluator · Supports [COL] references
   Functions: IF, MIN, MAX, ROUND, ABS, SUM, AVG, AND, OR, NOT, SQRT
   ============================================================ */
var TC_FORMULA = (function(){
  'use strict';

  var FUNCTIONS = {
    IF:    {a:3, fn:function(c,t,f){return c?t:f}},
    MIN:   {a:2, fn:Math.min},
    MAX:   {a:2, fn:Math.max},
    ROUND: {a:2, fn:function(v,d){var m=Math.pow(10,d);return Math.round(v*m)/m}},
    ABS:   {a:1, fn:Math.abs},
    SQRT:  {a:1, fn:Math.sqrt},
    SUM:   {a:-1, fn:function(){var s=0;for(var i=0;i<arguments.length;i++)s+=+arguments[i]||0;return s}},
    AVG:   {a:-1, fn:function(){var s=0,c=arguments.length;for(var i=0;i<c;i++)s+=+arguments[i]||0;return c?s/c:0}},
    AND:   {a:2, fn:function(a,b){return a&&b?1:0}},
    OR:    {a:2, fn:function(a,b){return a||b?1:0}},
    NOT:   {a:1, fn:function(a){return a?0:1}}
  };

  var OPS = {
    '+': {p:1,fn:function(a,b){return a+b}},
    '-': {p:1,fn:function(a,b){return a-b}},
    '*': {p:2,fn:function(a,b){return a*b}},
    '/': {p:2,fn:function(a,b){return b===0?0:a/b}},
    '%': {p:2,fn:function(a,b){return b===0?0:a%b}},
    '>': {p:0,fn:function(a,b){return a>b?1:0}},
    '<': {p:0,fn:function(a,b){return a<b?1:0}},
    '>=': {p:0,fn:function(a,b){return a>=b?1:0}},
    '<=': {p:0,fn:function(a,b){return a<=b?1:0}},
    '==': {p:0,fn:function(a,b){return a===b?1:0}},
    '!=': {p:0,fn:function(a,b){return a!==b?1:0}}
  };

  /* ── Tokenizer ── */
  function tokenize(expr){
    var tokens = [];
    var i = 0, len = expr.length;
    while(i < len){
      var ch = expr[i];
      if(ch === ' ' || ch === '\t' || ch === '\n'){ i++; continue; }
      // Column reference [NAME]
      if(ch === '['){
        var j = expr.indexOf(']', i);
        if(j === -1) throw 'Unclosed [ at ' + i;
        tokens.push({t:'COL', v:expr.substring(i+1,j).trim().toUpperCase()});
        i = j + 1; continue;
      }
      // Number
      if(ch >= '0' && ch <= '9' || (ch === '.' && i+1<len && expr[i+1]>='0' && expr[i+1]<='9')){
        var num = '';
        while(i < len && ((expr[i]>='0'&&expr[i]<='9')||expr[i]==='.')){num += expr[i]; i++;}
        tokens.push({t:'NUM', v:parseFloat(num)});
        continue;
      }
      // Two-char operators
      if(i+1<len){
        var two = ch + expr[i+1];
        if(OPS[two]){ tokens.push({t:'OP', v:two}); i+=2; continue; }
      }
      // Single-char operator
      if(OPS[ch]){ tokens.push({t:'OP', v:ch}); i++; continue; }
      // Parens and comma
      if(ch === '('){ tokens.push({t:'LP'}); i++; continue; }
      if(ch === ')'){ tokens.push({t:'RP'}); i++; continue; }
      if(ch === ','){ tokens.push({t:'SEP'}); i++; continue; }
      // Function or identifier
      if((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||ch==='_'){
        var id = '';
        while(i<len&&((expr[i]>='A'&&expr[i]<='Z')||(expr[i]>='a'&&expr[i]<='z')||(expr[i]>='0'&&expr[i]<='9')||expr[i]==='_')){id+=expr[i];i++;}
        var uid = id.toUpperCase();
        if(FUNCTIONS[uid]) tokens.push({t:'FN', v:uid});
        else tokens.push({t:'COL', v:uid});
        continue;
      }
      throw 'Unexpected character: ' + ch + ' at position ' + i;
    }
    return tokens;
  }

  /* ── Shunting-Yard → RPN ── */
  function toRPN(tokens){
    var out = [], stack = [];
    for(var i = 0; i < tokens.length; i++){
      var tk = tokens[i];
      if(tk.t === 'NUM' || tk.t === 'COL'){ out.push(tk); continue; }
      if(tk.t === 'FN'){ stack.push(tk); continue; }
      if(tk.t === 'SEP'){
        while(stack.length && stack[stack.length-1].t !== 'LP') out.push(stack.pop());
        continue;
      }
      if(tk.t === 'OP'){
        while(stack.length && stack[stack.length-1].t === 'OP' && OPS[stack[stack.length-1].v].p >= OPS[tk.v].p) out.push(stack.pop());
        stack.push(tk); continue;
      }
      if(tk.t === 'LP'){ stack.push(tk); continue; }
      if(tk.t === 'RP'){
        while(stack.length && stack[stack.length-1].t !== 'LP') out.push(stack.pop());
        if(stack.length) stack.pop(); // remove LP
        if(stack.length && stack[stack.length-1].t === 'FN') out.push(stack.pop());
        continue;
      }
    }
    while(stack.length) out.push(stack.pop());
    return out;
  }

  /* ── Evaluate RPN with row context ── */
  function runRPN(rpn, row){
    var stk = [];
    for(var i = 0; i < rpn.length; i++){
      var tk = rpn[i];
      if(tk.t === 'NUM'){ stk.push(tk.v); continue; }
      if(tk.t === 'COL'){
        var key = tk.v;
        var val = row[key]; if(val === undefined) val = row[key.toLowerCase()]; if(val === undefined) val = 0;
        stk.push(+val || 0);
        continue;
      }
      if(tk.t === 'OP'){
        var b = stk.pop(), a = stk.pop();
        stk.push(OPS[tk.v].fn(a||0, b||0));
        continue;
      }
      if(tk.t === 'FN'){
        var fn = FUNCTIONS[tk.v];
        var argc = fn.a;
        var args;
        if(argc === -1){
          args = stk.splice(0); // take all
        } else {
          args = stk.splice(-argc);
        }
        stk.push(fn.fn.apply(null, args));
        continue;
      }
    }
    return stk[0] || 0;
  }

  /* ── Compile: expr string → reusable evaluator ── */
  function compile(expr){
    var tokens = tokenize(expr);
    var rpn = toRPN(tokens);
    return function(row){ return runRPN(rpn, row); };
  }

  /* ── Get available column tokens from a calc result ── */
  function getColumnTokens(result){
    if(!result) return [];
    var keys = Object.keys(result);
    return keys.filter(function(k){ return typeof result[k] === 'number'; });
  }

  return {
    FUNCTIONS: FUNCTIONS,
    tokenize: tokenize,
    toRPN: toRPN,
    runRPN: runRPN,
    compile: compile,
    getColumnTokens: getColumnTokens
  };
})();