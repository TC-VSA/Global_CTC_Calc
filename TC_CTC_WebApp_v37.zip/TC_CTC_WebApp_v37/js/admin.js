/* ============================================================
   ADMIN.JS — Admin Panel Logic (v37)
   Client management, password control, backup/restore
   ============================================================ */
var TC_ADMIN = (function(){
  'use strict';
  var $ = function(id){ return document.getElementById(id); };

  /* ── Render Admin Table ── */
  function renderTable(){
    var body = $('admBody');
    if(!body) return;
    body.innerHTML = '';
    var clients = TC_DATA.CLIENTS;
    var codes = Object.keys(clients);
    $('aCount').textContent = codes.length;
    $('aClients').textContent = codes.length;
    var locked = 0, totalRows = 0;
    codes.forEach(function(code){
      var cl = clients[code];
      if(cl.pw) locked++;
      var rows = (cl.grid || []).length;
      totalRows += rows;
      var tr = document.createElement('tr');
      tr.innerHTML =
        '<td><b>'+code+'</b></td>'+
        '<td>'+(cl.state||'—')+'</td>'+
        '<td>'+(cl.cat||'—')+'</td>'+
        '<td><input type="password" value="'+(cl.pw||'')+'" data-code="'+code+'" class="adm-pw" style="width:120px"/></td>'+
        '<td>'+(cl.pw?'<span style="color:var(--ok)">🔒 Locked</span>':'<span style="color:var(--ink-40)">Open</span>')+'</td>'+
        '<td>'+rows+'</td>'+
        '<td><button class="btn ghost tiny" onclick="TC_ADMIN.savePw(\''+code+'\')">Save PW</button> '+
        '<button class="btn ghost tiny" onclick="TC_ADMIN.clearPw(\''+code+'\')">Clear</button> '+
        '<button class="btn ghost tiny danger" onclick="TC_ADMIN.removeClient(\''+code+'\')">Remove</button></td>';
      body.appendChild(tr);
    });
    $('aLocked').textContent = locked;
    $('aRows').textContent = totalRows;
    $('aFx').textContent = TC_GRID.getFxCols().length;
  }

  /* ── Save password for a client ── */
  function savePw(code){
    var inp = document.querySelector('input[data-code="'+code+'"]');
    if(!inp) return;
    TC_DATA.CLIENTS[code].pw = inp.value.trim();
    saveAll();
    renderTable();
    TC_UI.toast('Password saved for '+code);
  }

  /* ── Clear password ── */
  function clearPw(code){
    TC_DATA.CLIENTS[code].pw = '';
    saveAll();
    renderTable();
    TC_UI.toast('Password cleared for '+code);
  }

  /* ── Remove client ── */
  function removeClient(code){
    TC_UI.confirm('Remove Client', 'Delete client <b>'+code+'</b> and all its data?', function(){
      delete TC_DATA.CLIENTS[code];
      saveAll();
      renderTable();
      TC_UI.toast('Client '+code+' removed');
    });
  }

  /* ── Reveal/hide passwords ── */
  function toggleReveal(){
    var inputs = document.querySelectorAll('.adm-pw');
    var isPass = inputs[0] && inputs[0].type === 'password';
    inputs.forEach(function(inp){
      inp.type = isPass ? 'text' : 'password';
    });
  }

  /* ── Clear all passwords ── */
  function clearAllPw(){
    TC_UI.confirm('Clear All Passwords', 'Remove passwords from ALL clients?', function(){
      Object.keys(TC_DATA.CLIENTS).forEach(function(code){
        TC_DATA.CLIENTS[code].pw = '';
      });
      saveAll();
      renderTable();
      TC_UI.toast('All passwords cleared');
    });
  }

  /* ── Admin Password Change ── */
  function initAdminPw(){
    $('aPwSave') && $('aPwSave').addEventListener('click', function(){
      var old = $('aOld').value;
      var n1 = $('aNew').value;
      var n2 = $('aNew2').value;
      var currentPw = localStorage.getItem('TC_CTC_v37_adminPw') || TC_DATA.ADMIN_PW_DEFAULT;
      if(old !== currentPw){ TC_UI.toast('Current password incorrect'); return; }
      if(n1.length < 4){ TC_UI.toast('Minimum 4 characters'); return; }
      if(n1 !== n2){ TC_UI.toast('Passwords do not match'); return; }
      localStorage.setItem('TC_CTC_v37_adminPw', n1);
      $('aOld').value = ''; $('aNew').value = ''; $('aNew2').value = '';
      TC_UI.toast('Admin password updated');
    });
  }

  /* ── Backup/Restore ── */
  function initBackup(){
    $('aBackup') && $('aBackup').addEventListener('click', function(){
      var data = {
        version: 'v37',
        clients: TC_DATA.CLIENTS,
        cfg: TC_ENGINE.getCfg(),
        timestamp: new Date().toISOString()
      };
      TC_UI.downloadFile(JSON.stringify(data, null, 2), 'TC_CTC_Backup_'+Date.now()+'.json', 'application/json');
      TC_UI.toast('Backup exported');
    });

    $('aRestoreBtn') && $('aRestoreBtn').addEventListener('click', function(){ $('aRestoreFile').click(); });
    $('aRestoreFile') && $('aRestoreFile').addEventListener('change', function(e){
      var file = e.target.files[0];
      if(!file) return;
      var reader = new FileReader();
      reader.onload = function(ev){
        try {
          var data = JSON.parse(ev.target.result);
          if(data.clients) TC_DATA.CLIENTS = data.clients;
          if(data.cfg) TC_ENGINE.setCfg(data.cfg);
          saveAll();
          renderTable();
          TC_UI.toast('Backup restored');
        } catch(err){ TC_UI.toast('Invalid backup file'); }
      };
      reader.readAsText(file);
      e.target.value = '';
    });

    $('aFactory') && $('aFactory').addEventListener('click', function(){
      TC_UI.confirm('Factory Reset', '<b>WARNING:</b> This deletes ALL data. Are you sure?', function(){
        localStorage.removeItem('TC_CTC_v37');
        localStorage.removeItem('TC_CTC_v37_adminPw');
        location.reload();
      });
    });
  }

  /* ── Save to localStorage ── */
  function saveAll(){
    try {
      localStorage.setItem('TC_CTC_v37', JSON.stringify({
        clients: TC_DATA.CLIENTS,
        cfg: TC_ENGINE.getCfg()
      }));
    } catch(e){}
  }

  /* ── Init ── */
  function init(){
    initAdminPw();
    initBackup();
    $('aReveal') && $('aReveal').addEventListener('click', toggleReveal);
    $('aClearAllPw') && $('aClearAllPw').addEventListener('click', clearAllPw);
    renderTable();
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();

  return {
    renderTable: renderTable,
    savePw: savePw, clearPw: clearPw,
    removeClient: removeClient
  };
})();