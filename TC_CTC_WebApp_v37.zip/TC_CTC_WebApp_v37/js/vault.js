/* ============================================================
   VAULT.JS — Local Vault + AES-256 Encryption (v37)
   File System Access API · Automatic save/load · Encryption
   ============================================================ */
var TC_VAULT = (function(){
  'use strict';
  var $ = function(id){ return document.getElementById(id); };

  var _dirHandle = null;
  var _fileHandle = null;
  var _passphrase = null;
  var _isEncrypted = false;
  var VAULT_FILE = 'tc_ctc_vault.json';

  /* ── Status UI ── */
  function updateStatus(){
    var dot = $('vDot');
    var path = $('vPath');
    if(!dot || !path) return;
    if(_dirHandle){
      dot.classList.add('on');
      path.textContent = 'Connected: ' + (_dirHandle.name || 'Local folder');
    } else {
      dot.classList.remove('on');
      path.textContent = 'No folder linked';
    }
    // Encryption status
    var seal = $('encSeal');
    if(seal){
      seal.textContent = _isEncrypted ? 'Encrypted (AES-256)' : 'Not encrypted';
      seal.className = 'seal ' + (_isEncrypted ? 'on' : 'off');
    }
  }

  /* ── Pick folder (File System Access API) ── */
  async function pickFolder(){
    if(!window.showDirectoryPicker){
      TC_UI.toast('File System Access API not supported in this browser');
      return;
    }
    try {
      _dirHandle = await window.showDirectoryPicker({mode: 'readwrite'});
      updateStatus();
      TC_UI.toast('Vault folder linked: ' + _dirHandle.name);
    } catch(e){
      if(e.name !== 'AbortError') TC_UI.toast('Failed to pick folder');
    }
  }

  /* ── Save data to vault ── */
  async function saveNow(){
    if(!_dirHandle){
      // Fallback: download JSON
      downloadJSON();
      return;
    }
    try {
      _fileHandle = await _dirHandle.getFileHandle(VAULT_FILE, {create: true});
      var writable = await _fileHandle.createWritable();
      var data = {
        version: 'v37',
        clients: TC_DATA.CLIENTS,
        cfg: TC_ENGINE.getCfg(),
        timestamp: new Date().toISOString()
      };
      var content = JSON.stringify(data, null, 2);
      // Encrypt if passphrase is set
      if(_passphrase){
        content = await encryptAES(content, _passphrase);
        content = JSON.stringify({encrypted: true, data: content});
      }
      await writable.write(content);
      await writable.close();
      TC_UI.toast('Vault saved');
    } catch(e){
      TC_UI.toast('Save failed: ' + e.message);
    }
  }

  /* ── Load from vault ── */
  async function loadFromDisk(){
    if(!_dirHandle){
      TC_UI.toast('Pick a folder first');
      return;
    }
    try {
      _fileHandle = await _dirHandle.getFileHandle(VAULT_FILE);
      var file = await _fileHandle.getFile();
      var text = await file.text();
      var parsed = JSON.parse(text);
      // Check if encrypted
      if(parsed.encrypted){
        if(!_passphrase){
          TC_UI.toast('Data is encrypted. Enter passphrase first.');
          return;
        }
        text = await decryptAES(parsed.data, _passphrase);
        parsed = JSON.parse(text);
      }
      if(parsed.clients) TC_DATA.CLIENTS = parsed.clients;
      if(parsed.cfg) TC_ENGINE.setCfg(parsed.cfg);
      TC_UI.toast('Vault loaded');
    } catch(e){
      if(e.name === 'NotFoundError') TC_UI.toast('No vault file found');
      else TC_UI.toast('Load failed: ' + e.message);
    }
  }

  /* ── Download JSON (fallback) ── */
  function downloadJSON(){
    var data = {
      version: 'v37',
      clients: TC_DATA.CLIENTS,
      cfg: TC_ENGINE.getCfg(),
      timestamp: new Date().toISOString()
    };
    TC_UI.downloadFile(JSON.stringify(data, null, 2), 'tc_ctc_vault.json', 'application/json');
    TC_UI.toast('JSON downloaded');
  }

  /* ── AES-256 Encryption (Web Crypto API) ── */
  async function deriveKey(passphrase, salt){
    var enc = new TextEncoder();
    var keyMaterial = await crypto.subtle.importKey('raw', enc.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey(
      {name: 'PBKDF2', salt: salt, iterations: 100000, hash: 'SHA-256'},
      keyMaterial,
      {name: 'AES-GCM', length: 256},
      false,
      ['encrypt', 'decrypt']
    );
  }

  async function encryptAES(plaintext, passphrase){
    var enc = new TextEncoder();
    var salt = crypto.getRandomValues(new Uint8Array(16));
    var iv = crypto.getRandomValues(new Uint8Array(12));
    var key = await deriveKey(passphrase, salt);
    var encrypted = await crypto.subtle.encrypt({name: 'AES-GCM', iv: iv}, key, enc.encode(plaintext));
    // Combine: salt(16) + iv(12) + ciphertext
    var combined = new Uint8Array(salt.length + iv.length + encrypted.byteLength);
    combined.set(salt, 0);
    combined.set(iv, salt.length);
    combined.set(new Uint8Array(encrypted), salt.length + iv.length);
    return btoa(String.fromCharCode.apply(null, combined));
  }

  async function decryptAES(b64data, passphrase){
    var raw = Uint8Array.from(atob(b64data), function(c){return c.charCodeAt(0);});
    var salt = raw.slice(0, 16);
    var iv = raw.slice(16, 28);
    var ciphertext = raw.slice(28);
    var key = await deriveKey(passphrase, salt);
    var decrypted = await crypto.subtle.decrypt({name: 'AES-GCM', iv: iv}, key, ciphertext);
    return new TextDecoder().decode(decrypted);
  }

  /* ── Encryption UI ── */
  function initEncryption(){
    $('encApply') && $('encApply').addEventListener('click', function(){
      var p1 = $('encP1').value;
      var p2 = $('encP2').value;
      if(p1.length < 8){ TC_UI.toast('Minimum 8 characters'); return; }
      if(p1 !== p2){ TC_UI.toast('Passphrases do not match'); return; }
      _passphrase = p1;
      _isEncrypted = true;
      if($('encKeep').checked) localStorage.setItem('TC_CTC_v37_encKey', p1);
      updateStatus();
      TC_UI.toast('Encryption enabled');
    });

    $('encOff') && $('encOff').addEventListener('click', function(){
      _passphrase = null;
      _isEncrypted = false;
      localStorage.removeItem('TC_CTC_v37_encKey');
      updateStatus();
      TC_UI.toast('Encryption disabled');
    });

    $('encLock') && $('encLock').addEventListener('click', function(){
      if(!_passphrase){ TC_UI.toast('No passphrase set'); return; }
      saveNow();
      TC_UI.toast('Data locked');
    });

    // Restore key from keychain
    var saved = localStorage.getItem('TC_CTC_v37_encKey');
    if(saved){ _passphrase = saved; _isEncrypted = true; }
  }

  /* ── Init ── */
  function init(){
    $('vPick') && $('vPick').addEventListener('click', pickFolder);
    $('vSaveNow') && $('vSaveNow').addEventListener('click', saveNow);
    $('vLoad') && $('vLoad').addEventListener('click', loadFromDisk);
    $('vDownload') && $('vDownload').addEventListener('click', downloadJSON);
    initEncryption();
    updateStatus();
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();

  return {
    pickFolder: pickFolder, saveNow: saveNow,
    loadFromDisk: loadFromDisk, downloadJSON: downloadJSON
  };
})();