/* ============================================================
   UI.JS — Shared UI Helpers (v37)
   Toast, Modals, Formatters, Confirm dialogs
   ============================================================ */
var TC_UI = (function(){
  'use strict';

  var $ = function(id){ return document.getElementById(id); };

  /* ── Toast Notification ── */
  function toast(msg, dur){
    var el = $('toast');
    if(!el) return;
    var d = document.createElement('div');
    d.className = 't';
    d.textContent = msg;
    el.appendChild(d);
    setTimeout(function(){ if(d.parentNode) d.remove(); }, dur || 3000);
  }

  /* ── Currency Format ── */
  function fmt(n){
    if(n == null || isNaN(n)) return '—';
    return '\u20B9 ' + Math.round(n).toLocaleString('en-IN');
  }

  /* ── Confirm Modal ── */
  var _confirmCb = null;
  function confirm(title, bodyHtml, onYes){
    var modal = $('confirmModal');
    $('cmTitle').textContent = title;
    $('cmBody').innerHTML = bodyHtml;
    _confirmCb = onYes;
    modal.hidden = false;
  }
  function initConfirmModal(){
    var modal = $('confirmModal');
    if(!modal) return;
    $('cmNo').addEventListener('click', function(){ modal.hidden = true; _confirmCb = null; });
    $('cmYes').addEventListener('click', function(){
      modal.hidden = true;
      if(typeof _confirmCb === 'function') _confirmCb();
      _confirmCb = null;
    });
  }

  /* ── Password Authorisation Modal ── */
  var _pwCb = null;
  function promptPassword(title, body, checkFn, onSuccess){
    var modal = $('pwModal');
    if(!modal) return;
    $('pwTitle').textContent = title || 'Administrator authorisation';
    $('pwBody').textContent = body || 'Enter the administrator password to continue.';
    $('pwInput').value = '';
    $('pwErr').hidden = true;
    _pwCb = {check: checkFn, success: onSuccess};
    modal.hidden = false;
    setTimeout(function(){ $('pwInput').focus(); }, 100);
  }
  function initPwModal(){
    var modal = $('pwModal');
    if(!modal) return;
    $('pwNo').addEventListener('click', function(){ modal.hidden = true; _pwCb = null; });
    $('pwYes').addEventListener('click', function(){
      var val = $('pwInput').value;
      if(_pwCb && _pwCb.check(val)){
        modal.hidden = true;
        _pwCb.success();
        _pwCb = null;
      } else {
        $('pwErr').hidden = false;
      }
    });
    $('pwInput').addEventListener('keydown', function(e){
      if(e.key === 'Enter'){ e.preventDefault(); $('pwYes').click(); }
    });
  }

  /* ── Download helper ── */
  function downloadFile(content, filename, mime){
    var blob = new Blob([content], {type: mime || 'text/plain'});
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function(){ URL.revokeObjectURL(url); a.remove(); }, 100);
  }

  /* ── CSV Parser ── */
  function parseCSV(text){
    var lines = text.split(/\r?\n/).filter(function(l){return l.trim();});
    if(!lines.length) return {headers:[], rows:[]};
    var headers = lines[0].split(',').map(function(h){return h.trim().replace(/^"|"$/g,'');});
    var rows = [];
    for(var i=1;i<lines.length;i++){
      var cols = lines[i].split(',').map(function(c){return c.trim().replace(/^"|"$/g,'');});
      var obj = {};
      headers.forEach(function(h,j){ obj[h] = cols[j] || ''; });
      rows.push(obj);
    }
    return {headers: headers, rows: rows};
  }

  /* ── CSV Generator ── */
  function toCSV(headers, rows){
    var lines = [headers.join(',')];
    rows.forEach(function(row){
      var cols = headers.map(function(h){ return '"'+(row[h]||'')+'"'; });
      lines.push(cols.join(','));
    });
    return lines.join('\n');
  }

  /* ── Init ── */
  function init(){
    initConfirmModal();
    initPwModal();
  }

  // Auto-init on DOMContentLoaded
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init);
  else init();

  return {
    toast: toast, fmt: fmt, confirm: confirm,
    promptPassword: promptPassword,
    downloadFile: downloadFile,
    parseCSV: parseCSV, toCSV: toCSV
  };
})();