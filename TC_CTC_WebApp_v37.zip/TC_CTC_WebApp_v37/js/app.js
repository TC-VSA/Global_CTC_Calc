/* ============================================================
   APP.JS — Boot, Login, Tab Switch, Calc Form, State Manager (v37)
   Main entry point · Ties all modules together
   ============================================================ */
(function(){
  'use strict';

  /* ── State ── */
  var STATE = {
    role: null,       // 'admin' | 'client'
    clientCode: null,
    adminPw: null,
    cfg: null,
    lastResult: null
  };
  var LS_KEY = 'TC_CTC_v37';

  /* ── Helpers ── */
  var $ = function(id){ return document.getElementById(id); };
  var $$ = function(sel){ return document.querySelectorAll(sel); };

  function toast(msg, dur){
    var el = $('toast');
    var d = document.createElement('div');
    d.className = 't';
    d.textContent = msg;
    el.appendChild(d);
    setTimeout(function(){ d.remove(); }, dur || 3000);
  }

  function fmt(n){ return n == null ? '—' : '₹ ' + Math.round(n).toLocaleString('en-IN'); }

  /* ── LocalStorage persistence ── */
  function saveState(){
    try { localStorage.setItem(LS_KEY, JSON.stringify({
      adminPw: STATE.adminPw,
      clients: TC_DATA.CLIENTS,
      cfg: STATE.cfg
    })); } catch(e){}
  }
  function loadState(){
    try {
      var raw = localStorage.getItem(LS_KEY);
      if(!raw) return;
      var obj = JSON.parse(raw);
      if(obj.adminPw) STATE.adminPw = obj.adminPw;
      if(obj.clients) TC_DATA.CLIENTS = obj.clients;
      if(obj.cfg) STATE.cfg = obj.cfg;
    } catch(e){}
  }

  /* ── Initialize Config ── */
  function initCfg(){
    if(!STATE.cfg) STATE.cfg = JSON.parse(JSON.stringify(TC_DATA.CFG_DEFAULT));
    TC_ENGINE.setCfg(STATE.cfg);
  }

  /* ── Populate State Dropdown ── */
  function populateStates(){
    var sel = $('f_state');
    if(!sel) return;
    sel.innerHTML = '';
    TC_DATA.MW_SEED.forEach(function(row){
      var opt = document.createElement('option');
      opt.value = row.s;
      opt.textContent = row.s;
      sel.appendChild(opt);
    });
  }

  /* ── Populate MW Table (Config tab) ── */
  function populateMWTable(){
    var body = $('mwBody');
    if(!body) return;
    body.innerHTML = '';
    TC_DATA.MW_SEED.forEach(function(row){
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>'+row.s+'</td><td>'+row.r+'</td><td>'+fmt(row.u)+'</td><td>'+fmt(row.ss)+'</td><td>'+fmt(row.sk)+'</td><td>'+fmt(row.hs)+'</td>';
      body.appendChild(tr);
    });
  }

  /* ── LOGIN / GATE ── */
  function initGate(){
    var gate = $('gate');
    var form = $('gateForm');
    var roleClient = $('roleClient');
    var roleAdmin  = $('roleAdmin');
    var clientField = $('gateClientField');
    var pwLab = $('gatePwLab');
    var gateErr = $('gateErr');
    var eyeBtn = $('gateEye');
    var pwInput = $('gatePw');

    // Role switch
    roleClient.addEventListener('click', function(){
      roleClient.setAttribute('aria-pressed','true');
      roleAdmin.setAttribute('aria-pressed','false');
      clientField.hidden = false;
      pwLab.textContent = 'Password';
    });
    roleAdmin.addEventListener('click', function(){
      roleAdmin.setAttribute('aria-pressed','true');
      roleClient.setAttribute('aria-pressed','false');
      clientField.hidden = true;
      pwLab.textContent = 'Admin Password';
    });

    // Eye toggle
    eyeBtn.addEventListener('click', function(){
      var isPass = pwInput.type === 'password';
      pwInput.type = isPass ? 'text' : 'password';
      eyeBtn.textContent = isPass ? 'HIDE' : 'SHOW';
    });

    // Submit
    form.addEventListener('submit', function(e){
      e.preventDefault();
      gateErr.hidden = true;
      var isAdmin = roleAdmin.getAttribute('aria-pressed') === 'true';
      var pw = pwInput.value.trim();

      if(isAdmin){
        var correctPw = STATE.adminPw || TC_DATA.ADMIN_PW_DEFAULT;
        if(pw !== correctPw){
          gateErr.textContent = 'Incorrect admin password.';
          gateErr.hidden = false;
          return;
        }
        STATE.role = 'admin';
        STATE.clientCode = null;
        enterApp();
      } else {
        var code = ($('gateClient').value || '').trim().toUpperCase();
        if(!code){
          gateErr.textContent = 'Enter a company code.';
          gateErr.hidden = false;
          return;
        }
        // Check if client exists; if not, create a new one (admin creates, client uses)
        var client = TC_DATA.CLIENTS[code];
        if(client && client.pw && pw !== client.pw){
          gateErr.textContent = 'Incorrect client password.';
          gateErr.hidden = false;
          return;
        }
        if(!client){
          TC_DATA.CLIENTS[code] = { code:code, pw:'', state:'Delhi', cat:'SEMI-SKILLED', name:code, grid:[], fxCols:[] };
          saveState();
        }
        STATE.role = 'client';
        STATE.clientCode = code;
        enterApp();
      }
    });
  }

  /* ── Enter App (after login) ── */
  function enterApp(){
    var gate = $('gate');
    gate.classList.add('off');
    setTimeout(function(){ gate.style.display = 'none'; }, 500);

    // Set body class
    if(STATE.role === 'admin') document.body.classList.add('is-admin');
    else document.body.classList.remove('is-admin');

    // Update session bar
    $('sessRole').textContent = STATE.role === 'admin' ? 'Administrator' : 'Client User';
    $('sessClient').textContent = STATE.clientCode || '—';
    $('sessClientChip').style.display = STATE.clientCode ? '' : 'none';

    // Show/hide admin tab
    var admTab = $('tab-admin');
    if(admTab) admTab.hidden = STATE.role !== 'admin';

    // If client, set form defaults from client config
    if(STATE.clientCode){
      var cl = TC_DATA.CLIENTS[STATE.clientCode];
      if(cl && cl.state) $('f_state').value = cl.state;
      if(cl && cl.cat) $('f_cat').value = cl.cat;
    }

    // Run initial calc
    doCalc();
    populateMWTable();
    toast('Welcome, ' + (STATE.role === 'admin' ? 'Administrator' : STATE.clientCode) + '!');
  }

  /* ── LOGOUT ── */
  function initLogout(){
    $('btnLogout').addEventListener('click', function(){
      STATE.role = null;
      STATE.clientCode = null;
      document.body.classList.remove('is-admin');
      var gate = $('gate');
      gate.style.display = '';
      gate.classList.remove('off');
      $('gatePw').value = '';
      $('gateClient').value = '';
      $('gateErr').hidden = true;
    });
  }

  /* ── TAB NAVIGATION ── */
  function initTabs(){
    var tabs = $$('.tab');
    var panels = $$('.panel');
    tabs.forEach(function(tab){
      tab.addEventListener('click', function(){
        tabs.forEach(function(t){ t.setAttribute('aria-selected','false'); });
        panels.forEach(function(p){ p.classList.remove('on'); });
        tab.setAttribute('aria-selected','true');
        var target = tab.getAttribute('aria-controls');
        var panel = $(target);
        if(panel) panel.classList.add('on');
      });
    });
  }

  /* ── CALCULATOR FORM ── */
  function doCalc(){
    var basis = $('f_basis').value;
    var amt   = +$('f_amt').value || 0;
    var params = {
      name:    $('f_name').value,
      state:   $('f_state').value,
      cat:     $('f_cat').value,
      pf:      $('f_pf').value,
      metro:   $('f_metro').value,
      bonus:   $('f_bonus').value,
      pfBasis: $('f_pfb') ? $('f_pfb').value : 'On 15K',
      etype:   $('f_etype') ? $('f_etype').value : 'REGULAR EMP',
      da:      $('f_da') ? +$('f_da').value : 0,
      fix:     $('f_fix') ? +$('f_fix').value : 0,
      incentPct: +$('f_incent').value || 0
    };

    var r;
    if(basis === 'CTC'){
      r = TC_ENGINE.solveWagesForCTC(amt, params);
    } else if(basis === 'NETTH'){
      r = TC_ENGINE.solveWagesForNTH(amt, params);
    } else {
      params.wages = amt;
      r = TC_ENGINE.calc(params);
    }
    STATE.lastResult = r;
    renderResult(r);
    return r;
  }

  function renderResult(r){
    // KPIs
    var kpis = $('kpis');
    kpis.innerHTML =
      '<div class="kpi"><div class="k">Monthly CTC</div><div class="v">'+fmt(r.ctc)+'</div></div>'+
      '<div class="kpi"><div class="k">Annual CTC</div><div class="v">'+fmt(r.ctc*12)+'</div></div>'+
      '<div class="kpi"><div class="k">Net Take Home</div><div class="v">'+fmt(r.nth)+'</div></div>'+
      '<div class="kpi"><div class="k">Total Wages</div><div class="v">'+fmt(r.wages)+'</div></div>'+
      (r.incentive ? '<div class="kpi"><div class="k">TTC (CTC+Incent)</div><div class="v">'+fmt(r.ttc)+'</div></div>' : '');

    // Salary slip table
    var body = $('slipBody');
    var rows = [
      ['Basic',r.basic],['DA',r.da],['HRA',r.hra],['Conveyance',r.conv],
      ['Special Allowance',r.specAllow],['Gross Salary',r.gross],
      ['—','—'],
      ['PF (Employee)',r.pfEE],['PF (Employer)',r.pfER],
      ['ESI (Employee)',r.esiEE],['ESI (Employer)',r.esiER],
      ['EDLI',r.edli],['Admin Charge',r.admChg],
      ['Bonus',r.bonus],['Gratuity',r.gratuity],
      ['Prof Tax',r.profTax],
      ['—','—'],
      ['Total Deductions',r.totalDeductions],
      ['Net Take Home',r.nth],
      ['CTC (Monthly)',r.ctc],['CTC (Annual)',r.ctc*12]
    ];
    if(r.incentive) rows.push(['Incentive',r.incentive],['TTC',r.ttc]);
    body.innerHTML = '';
    rows.forEach(function(row){
      if(row[0]==='—'){body.innerHTML+='<tr><td colspan="3" style="height:4px;background:var(--rule)"></td></tr>';return;}
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>'+row[0]+'</td><td style="text-align:right">'+fmt(row[1])+'</td><td style="text-align:right">'+fmt((row[1]||0)*12)+'</td>';
      body.appendChild(tr);
    });

    // Alerts
    var alerts = $('calcAlerts');
    alerts.innerHTML = '';
    if(r.esiApplicable) alerts.innerHTML += '<div class="alert warn">ESI applicable — gross ≤ ₹'+r.gross.toLocaleString('en-IN')+'</div>';
    if(r.basic <= r.mw) alerts.innerHTML += '<div class="alert ok">Basic = Minimum Wage ('+r.state+': '+fmt(r.mw)+')</div>';
  }

  function initCalcForm(){
    // Auto-calc on any change
    var inputs = ['f_state','f_cat','f_basis','f_amt','f_pf','f_esi','f_metro','f_pfb','f_etype','f_bonus','f_incent','f_da','f_fix'];
    inputs.forEach(function(id){
      var el = $(id);
      if(el) el.addEventListener('change', doCalc);
      if(el && el.tagName === 'INPUT') el.addEventListener('input', doCalc);
    });

    // Reset button
    $('btnReset').addEventListener('click', function(){
      $('f_amt').value = 24347;
      $('f_incent').value = 0;
      if($('f_da')) $('f_da').value = 0;
      if($('f_fix')) $('f_fix').value = 0;
      doCalc();
      toast('Form reset');
    });

    // Push to Grid
    var pushBtn = $('btnPush');
    if(pushBtn){
      pushBtn.addEventListener('click', function(){
        if(!STATE.lastResult){ toast('Calculate first'); return; }
        toast('Push to Grid — use Employee Grid tab');
        // Switch to grid tab
        $('tab-grid').click();
      });
    }
  }

  /* ── CONFIG FORM (Statutory Constants) ── */
  function initCfgForm(){
    var body = $('cfgBody');
    if(!body) return;
    var keys = Object.keys(TC_DATA.CFG_DEFAULT);
    body.innerHTML = '';
    keys.forEach(function(k){
      var div = document.createElement('div');
      div.className = 'field';
      div.innerHTML = '<label for="cfg_'+k+'">'+k.replace(/_/g,' ')+'</label><input id="cfg_'+k+'" type="number" step="any" value="'+(STATE.cfg[k]||0)+'"/>';
      body.appendChild(div);
    });

    $('cfgSave').addEventListener('click', function(){
      keys.forEach(function(k){
        var el = $('cfg_'+k);
        if(el) STATE.cfg[k] = parseFloat(el.value) || 0;
      });
      TC_ENGINE.setCfg(STATE.cfg);
      saveState();
      doCalc();
      toast('Constants applied');
    });

    $('cfgReset').addEventListener('click', function(){
      STATE.cfg = JSON.parse(JSON.stringify(TC_DATA.CFG_DEFAULT));
      TC_ENGINE.setCfg(STATE.cfg);
      initCfgForm(); // re-render
      doCalc();
      saveState();
      toast('Defaults restored');
    });
  }

  /* ── BOOT ── */
  function boot(){
    loadState();
    initCfg();
    if(!STATE.adminPw) STATE.adminPw = TC_DATA.ADMIN_PW_DEFAULT;
    TC_ASSETS.applyLogos();
    populateStates();
    initGate();
    initLogout();
    initTabs();
    initCalcForm();
    initCfgForm();
    console.log('[TC CTC v37] Booted — multi-file web app');
  }

  // Start
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();