/* ============================================================
   GRID.JS — Employee Grid CRUD Module (v37)
   Add, Duplicate, Import CSV, Export CSV/JSON, Recalculate
   ============================================================ */
var TC_GRID = (function(){
  'use strict';
  var $ = function(id){ return document.getElementById(id); };

  var GRID = []; // active grid data
  var FX_COLS = []; // formula columns

  /* ── Core columns ── */
  var CORE_COLS = ['name','state','cat','wages','pf','metro','bonus','pfBasis','etype',
    'basic','da','hra','specAllow','gross','pfEE','pfER','esiEE','esiER','bonus_amt',
    'gratuity','profTax','nth','ctc','ttc'];

  /* ── Render grid header ── */
  function renderHeader(){
    var head = $('dgHead');
    if(!head) return;
    var tr = document.createElement('tr');
    tr.innerHTML = '<th>#</th><th>Name</th><th>State</th><th>Category</th><th>Wages</th>'+
      '<th>PF</th><th>Metro</th><th>Basic</th><th>HRA</th><th>Gross</th>'+
      '<th>PF-EE</th><th>ESI-EE</th><th>NTH</th><th>CTC</th><th>Actions</th>';
    // Add formula columns
    FX_COLS.forEach(function(fc){
      var th = document.createElement('th');
      th.textContent = fc.name;
      tr.insertBefore(th, tr.lastChild);
    });
    head.innerHTML = '';
    head.appendChild(tr);
  }

  /* ── Render grid body ── */
  function renderBody(){
    var body = $('dgBody');
    if(!body) return;
    body.innerHTML = '';
    var totalCtc = 0;
    GRID.forEach(function(row, idx){
      totalCtc += (row.ctc || 0);
      var tr = document.createElement('tr');
      tr.innerHTML = '<td>'+(idx+1)+'</td>'+
        '<td><input value="'+(row.name||'')+'" data-i="'+idx+'" data-f="name"/></td>'+
        '<td>'+(row.state||'')+'</td>'+
        '<td>'+(row.cat||'')+'</td>'+
        '<td style="text-align:right">'+(row.wages||0)+'</td>'+
        '<td>'+(row.pfApplicable?'Y':'N')+'</td>'+
        '<td>'+(row.metro?'Y':'N')+'</td>'+
        '<td style="text-align:right">'+(row.basic||0)+'</td>'+
        '<td style="text-align:right">'+(row.hra||0)+'</td>'+
        '<td style="text-align:right">'+(row.gross||0)+'</td>'+
        '<td style="text-align:right">'+(row.pfEE||0)+'</td>'+
        '<td style="text-align:right">'+(row.esiEE||0)+'</td>'+
        '<td style="text-align:right">'+(row.nth||0)+'</td>'+
        '<td style="text-align:right;font-weight:700">'+(row.ctc||0)+'</td>';
      // Formula column values
      FX_COLS.forEach(function(fc){
        var td = document.createElement('td');
        td.style.textAlign = 'right';
        try {
          var val = fc.evaluator(row);
          td.textContent = (fc.prefix||'') + (fc.decimals != null ? val.toFixed(fc.decimals) : Math.round(val));
        } catch(e){ td.textContent = 'ERR'; }
        tr.insertBefore(td, null);
      });
      // Actions
      var actTd = document.createElement('td');
      actTd.innerHTML = '<button onclick="TC_GRID.removeRow('+idx+')">Del</button>';
      tr.appendChild(actTd);
      body.appendChild(tr);
    });
    // Update stats
    $('cRows').textContent = GRID.length;
    $('cCols').textContent = FX_COLS.length;
    $('cSum').textContent = Math.round(totalCtc).toLocaleString('en-IN');
  }

  /* ── Add row from calc result ── */
  function addRow(result){
    if(!result) return;
    GRID.push(JSON.parse(JSON.stringify(result)));
    renderHeader();
    renderBody();
  }

  /* ── Remove row ── */
  function removeRow(idx){
    GRID.splice(idx, 1);
    renderBody();
  }

  /* ── Duplicate last row ── */
  function dupeLast(){
    if(!GRID.length){ TC_UI.toast('No rows to duplicate'); return; }
    var last = JSON.parse(JSON.stringify(GRID[GRID.length-1]));
    last.name = (last.name||'') + ' (copy)';
    GRID.push(last);
    renderBody();
  }

  /* ── Clear all ── */
  function clearAll(){
    TC_UI.confirm('Clear Grid','Remove ALL employee rows?', function(){
      GRID = [];
      renderBody();
      TC_UI.toast('Grid cleared');
    });
  }

  /* ── Export CSV ── */
  function exportCSV(){
    if(!GRID.length){ TC_UI.toast('No data'); return; }
    var headers = ['name','state','cat','wages','basic','hra','gross','pfEE','esiEE','nth','ctc'];
    var csv = TC_UI.toCSV(headers, GRID);
    TC_UI.downloadFile(csv, 'TC_CTC_Grid.csv', 'text/csv');
    TC_UI.toast('CSV exported');
  }

  /* ── Export JSON ── */
  function exportJSON(){
    if(!GRID.length){ TC_UI.toast('No data'); return; }
    TC_UI.downloadFile(JSON.stringify(GRID, null, 2), 'TC_CTC_Grid.json', 'application/json');
    TC_UI.toast('JSON exported');
  }

  /* ── Import CSV ── */
  function importCSV(file){
    var reader = new FileReader();
    reader.onload = function(e){
      var parsed = TC_UI.parseCSV(e.target.result);
      parsed.rows.forEach(function(row){
        var params = {
          name: row.name || row.Name || '',
          state: row.state || row.State || 'Delhi',
          cat: row.cat || row.Category || 'SEMI-SKILLED',
          wages: +row.wages || +row.Wages || 0,
          pf: (row.pf || row.PF || 'Y').toUpperCase() === 'Y' ? 'Y' : 'N',
          metro: (row.metro || row.Metro || 'N').toUpperCase() === 'Y' ? 'Y' : 'N',
          bonus: (row.bonus || row.Bonus || 'Y').toUpperCase() === 'Y' ? 'Y' : 'N',
          pfBasis: row.pfBasis || 'On 15K',
          etype: row.etype || 'REGULAR EMP',
          incentPct: 0
        };
        var result = TC_ENGINE.calc(params);
        GRID.push(result);
      });
      renderHeader();
      renderBody();
      TC_UI.toast(parsed.rows.length + ' rows imported');
    };
    reader.readAsText(file);
  }

  /* ── Download CSV Template ── */
  function downloadTemplate(){
    var tpl = 'name,state,cat,wages,pf,metro,bonus\nJohn Doe,Delhi,SEMI-SKILLED,25000,Y,Y,Y\nJane Doe,Maharashtra,SKILLED,30000,Y,N,Y';
    TC_UI.downloadFile(tpl, 'TC_CTC_Template.csv', 'text/csv');
  }

  /* ── Add formula column ── */
  function addFxCol(name, expr, decimals, prefix){
    var evaluator = TC_FORMULA.compile(expr);
    FX_COLS.push({ name:name, expr:expr, decimals:decimals||0, prefix:prefix||'', evaluator:evaluator });
    renderHeader();
    renderBody();
  }

  /* ── Init grid buttons ── */
  function init(){
    $('gAdd') && $('gAdd').addEventListener('click', function(){ TC_UI.toast('Use Calculator → Push to Grid'); });
    $('gDupe') && $('gDupe').addEventListener('click', dupeLast);
    $('gClear') && $('gClear').addEventListener('click', clearAll);
    $('gCsv') && $('gCsv').addEventListener('click', exportCSV);
    $('gJson') && $('gJson').addEventListener('click', exportJSON);
    $('gTpl') && $('gTpl').addEventListener('click', downloadTemplate);
    $('gImport') && $('gImport').addEventListener('click', function(){ $('fileCsv').click(); });
    $('fileCsv') && $('fileCsv').addEventListener('change', function(e){
      if(e.target.files[0]) importCSV(e.target.files[0]);
      e.target.value = '';
    });
    renderHeader();
    renderBody();
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();

  return {
    addRow: addRow, removeRow: removeRow, dupeLast: dupeLast,
    clearAll: clearAll, exportCSV: exportCSV, exportJSON: exportJSON,
    addFxCol: addFxCol, getGrid: function(){return GRID;},
    getFxCols: function(){return FX_COLS;}
  };
})();